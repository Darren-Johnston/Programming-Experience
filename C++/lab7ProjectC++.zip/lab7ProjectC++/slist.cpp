//*******************************************************************
// IMPLEMENTATION FILE (slist.cpp)
//*******************************************************************
#include"slist.h"
#include<iostream>

using namespace std;

//Private members of class
//      int  length
//      int  currentPos
// ItemType  data[MAX_LENGTH]

SortedList::SortedList()
// Constructor
// Postcondition:
//	 Empty list is created

{
	length = 0;
}

bool SortedList::IsEmpty() const
// Reports whether list is empty
// Postcondition:
//	Function value == true if list is empty
//				   == false, otherwise

{
	return (length == 0);
}

bool SortedList::IsFull() const
// Reports whether list is full
// Postcondition:
//	Function value == true if list is full
//				   == false, otherwise

{
	return (length == MAX_LENGTH);
}

int SortedList::Length() const
// Returns current length of list
// Postcondition:
//	Function value == length of list

{
	return length;
}

void SortedList::Insert(/* in */ ItemType item)
// Inserts item into the list
// Precondition:
//	   length < MAX_LENGTH 
//  && data[0..length - 1] are in ascending order
//  && item is assigned
// Postcondition:
//  item is in list
//  && Length() == Length()@entry + 1
//  && data[0..length-1] are in ascending order

{
	int index;   //Index and loop control variable
    
	index = length - 1;
	while (index>= 0 && item.stockNo < data[index].stockNo)
        {
		data[index+1] = data[index];
		index--;
        }
	data[index+1] = item;     //Insert item
	length++;
}

void SortedList::Delete( /* in */ ItemType item)
// Deletes an item from the list, if it is there
// Precondition
//	0 < length <= INT_MAX/2
//  && data[0..length-1] are in ascending order
//  && item is assigned
// Postcondition:
//	IF item is in list at entry
//		First occurrence of item is no longer in list
//		&& Length() == Length()@entry - 1
//      && data[0..length-1] are in ascending oder
//	ELSE
//		length and data array are unchanged

{
	bool found;
	int position;
	int index;
    
	BinSearch(item, found, position);
	if (found)
        {
		//shift data[position..length-1] up one position
        
        for (index = position; index < length - 1; index++)
            data[index] = data[index+1];
        
        length--;
        }
}

void SortedList::Reset()
// Postcondition:
//   Iteration is initialized
{
	currentPos = 0;
}

ItemType SortedList::GetNextItem()
// Precondition:
// Iteration has been initialized by call to Reset()
//   No transformers have been called since last call
// Postcondition
//   Returns item at the current position in the 
//   SortedList
//  If last item has been returned, the next call
//  returns the first item
{
	ItemType item;
	item = data[currentPos];
	if (currentPos == length - 1)
		currentPos = 0;
	else
		currentPos++;
	return item;
}

void SortedList::BinSearch(/* in */  ItemType item,
						   /* out */ bool& found,
						   /* out */ int& position) const

//Searches list for item, returning the index
//of item if item was found

//Precondition:
//     length <= INT_MAX /2
//  && data[0..length-1] are in ascending order
//  &&  item is assigned
//Postcondition:
//     If item is in the list
//        found == true && data[position[ contains item
//     ELSE
//        found == false && position is undefined

{
	int first = 0;
	int last = length - 1;
	int middle;
    
	found = false;
    
	while (last >= first && !found)
        {
		middle = (first + last) / 2;
		if (item.stockNo  < data[middle].stockNo)
			last = middle - 1;
		else if (item.stockNo  > data[middle].stockNo)
			first = middle + 1;
		else
			found = true;
        }
	if (found)
		position = middle;
    
}
bool SortedList::IsPresent(/* in */ ItemType item) const
// Searches the list for item, reporting whether it was found
// Precondition:
//     length <= INT_MAX / 2
//  && data[0..length-1] are in ascending order
//	&& item is assigned
// Postcondition:
//	Function value == true, if item is in data[0..length-1]
//				   == false, otherwise

{
	bool found;
	int position;
    
	BinSearch(item, found, position);
	return found;
}

