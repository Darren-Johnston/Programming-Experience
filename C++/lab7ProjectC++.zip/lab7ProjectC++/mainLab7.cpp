//Author: Darren Johnston

#include<iostream>
#include<stdlib.h>
#include<iomanip>
#include<string>
#include<fstream>
#include"slist.h" //Save this correctly or you will have a bad time.

using namespace std;
int main()
{
	// Identify all of the variables
	int i;
	ItemType Inventory;
	SortedList list;
	fstream inData;
    char userInput;
    bool done;
    cout<<fixed<<showpoint<<setprecision(2);
    
    inData.open("Inventory.txt");
	if(!inData)
        cout<<"Could not find file."<<endl;
    
	inData>>Inventory.stockNo>>Inventory.quantity>>Inventory.cost;
    
	while(inData)
	{
	list.Insert(Inventory);
	inData>>Inventory.stockNo>>Inventory.quantity>>Inventory.cost;
	}
	
    
    do
	{
    	done = false;
    //Set the menu
	cout<<endl;	
    cout<<"ITEM            DESCRIPTION"<<endl;
    //cout<<"----            -----------"<<endl;
    cout<<" 1              List the data (all numbers) to the screen"<<endl;
    cout<<" 2              Add a new item to the list"<<endl;
    cout<<" 3              Delete an item from the list"<<endl;
    cout<<" 4              Display the current length of the list"<<endl;
    cout<<" 5              Find the price of a specific item "<<endl;
    cout<<" 9              Stop"<<endl;
    cout<<endl;
    cout<<"Please input an item 1, 2, 3, 4, 5, or 9 to end program: "<<endl;
    cin>>userInput;
    cout<<endl;
    
    //Set the inputs that the menu will use
    if(userInput == '1')
	    {
	    cout<<"Stock Number        Current Quantity          Inventory Cost"<<endl;
	    ItemType items;
	    list.Reset();
	    //cout<<"You have chosen to list the current inventory.";
	    
		    for(i = 0; i < list.Length(); i++)
			{
				
	        items = list.GetNextItem();
	        cout<<items.stockNo<<setw(20) <<items.quantity<<setw(28)<<items.cost<<endl;
	        
	    	}
    	
	    }
	    

	else if(userInput == '2')
		{   
	    cout<<endl;
	    ItemType stockObject;
	    cout<<"What is the new item stock number? ";
	    cin>>stockObject.stockNo;
	    cout<<"What is the quantity of the new item? ";
	    cin>>stockObject.quantity;
	    cout<<"What is the price of the new item? ";
	    cin>>stockObject.cost;
	    list.Insert(stockObject);
	    cout<<endl;
	    cout<<endl;
		}
			
	else if(userInput == '3')
	{
	    cout<<endl;
	    ItemType item;
	    cout<<"What is the stock number of the item you want to delete? ";
	    cin>>item.stockNo;
	    list.Reset();
	    
		    if(list.IsPresent(item)) 
				{
			        list.Delete(item);
			        cout<<endl<<"The item has been deleted."<<endl;
			    }
	    
		    else
		        cout<<endl<<"The number you typed did not match any of the numbers. Please try again."<<endl<<endl;
	}
		
	else if(userInput == '4')
	{
		int i;
		int sum;
	    sum = 0;
	    for(i = 0; i < list.Length(); i++)
	        sum++;
	    cout<<"The length of the list is: "<<sum<<endl;	
	}
	
	else if(userInput == '5')
	{
	cout<<endl;
	ItemType item;
	cout<<"What is the stock number of the item you want to find the price of: ";
	cin>>item.stockNo;
	list.Reset();
	
		if(list.IsPresent(item)) 
			{
			    cout<<endl<<"The price is "<<item.cost<<endl;
			}
		
		else
		cout<<endl<<"The number you typed did not match any numbers on record. Please try again."<<endl<<endl;
		}
	else if(userInput == '9')
                        done = true;
                else
                {
                 cout<<"The choice is invalid."<<endl;
                 
             	}
            
                cout<<endl<<endl;
                
                
    if (userInput != '9')
	{
		system("pause");
                 system("cls");
	}            
                
    } while (!done);  
        cout<<"You have now ended the inventory program."<<endl<<endl;
        return 0;

}
