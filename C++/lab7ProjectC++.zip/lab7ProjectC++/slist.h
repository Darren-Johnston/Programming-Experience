//*******************************************************************
// SPECIFICATION FILE (slist.h)
//*******************************************************************

#include<string>
using namespace std;

const int MAX_LENGTH = 100;

struct StructType {
    
	string stockNo;
	int quantity;
	float cost;
};

typedef StructType ItemType;

class SortedList {
    
public:
	bool IsEmpty() const;
    // Postcondition:
    //	Function value == true if list is empty
    //				   == false, otherwise
    
	bool IsFull() const;
    // Postcondition:
    //	Function value == true if list is full
    //				   == false, otherwise
    
	int Length() const;
    // Postcondition:
    //	Function value == length of list
    
	void Insert(/* in */ ItemType item);
    // Precondition:
    //	NOT IsFull()
    //  && item is assigned
    // Postcondition:
    //  item is in the SortedList
    //  && Length() == Length()@entry + 1
    //  && data[0..length-1] are in ascending order
    
	void Delete( /* in */ ItemType item);
    // Precondition
    //	NOT IsEmpty()
    //  && item is assigned
    // Postcondition:
    //	IF item is in list at entry
    //		First occurrence of item is no longer in list
    //		&& Length() == Length()@entry - 1
    //	ELSE
    //		List is unchanged
    
	bool IsPresent(/* in */ ItemType item) const;
    // Precondition:
    //	item is assigned
    // Postcondition:
    //	Function value == true, if item is in list
    //				   == false, otherwise
    
	void Reset();
    // Postcondition:
    //   Iteration is initialized
    
	ItemType GetNextItem();
    // Precondition:
    // Iteration has been initialized by call to Reset()
    //   No transformers have been called since last call
    // Postcondition
    //   Returns item at the current position in the 
    //   SortedList
    
	SortedList();
    // Constructor
    // Postcondition:
    //	 Empty list is created
    
private:
	int		 length;
	int      currentPos;
	ItemType data[MAX_LENGTH];
	void     BinSearch(ItemType, bool&, int&) const;
    
};
