#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>	//C standard Library
#include<stdlib.h>

using namespace std;

struct NodeType // record with three components
{
	string name;
	int grade;
	NodeType* link; // make me a pointer called link that will point to this nodetype
};

typedef NodeType* NodePtr; //make a pointer that points to a structure NodeType
typedef int ComponentType;  
typedef string ComponentString;

void InsertHead(NodeType, NodePtr&); 
void Print(NodePtr);
void InsertSorted(NodePtr&, NodeType);
void DeleteList(NodePtr&);
bool IsPresent(NodePtr, NodeType);
void DeleteItem(NodePtr&, NodeType);

int main()
{
	NodeType temp;
	ifstream inFile;
	char userChoice;
	NodeType newStudent;
	NodeType deleteStudent;
	NodePtr head = NULL;								
	inFile.open("studentLab8.txt");
	if (!inFile)
	{
		cout<<"Error"<<endl;
		return 1;
	}
	inFile>>temp.name>>temp.grade;
	while(inFile)
	{
		InsertSorted(head,temp); 
		inFile>>temp.name>>temp.grade;
		
	}
while(userChoice != '9')
{
	
	cout<<"ITEM            DESCRIPTION"<<endl;
    //cout<<"----            -----------"<<endl;
    cout<<" 1              List the students to the screen"<<endl;
    cout<<" 2              Add a new student to the list"<<endl;
    cout<<" 3              Delete an student from the list"<<endl;
    cout<<" 9              Stop"<<endl;
    cout<<endl;
    cout<<"Please input an item 1, 2, 3, or 9 to end program: ";
	cin>>userChoice;
	
	
	if (userChoice == '1')
	{
		cout<<endl;
		cout<<"The student's data is: "<<endl;
		Print(head);
	}
	
	else if (userChoice == '2')
	{
		//head = NULL;
		cout<<"Choose a student to add: ";
		cin>>newStudent.name;
		cout<<"What overall grade is this student making: ";
		cin>>newStudent.grade;
		InsertSorted(head, newStudent);
		cout<<endl;
		cout<<"The student has been added."<<endl;
	}
	
	else if (userChoice == '3')
	{
		cout<<"Whats the name of the student you want to delete: ";
		cin>>deleteStudent.name;
		
		if (IsPresent(head, deleteStudent))
		{
			DeleteItem(head, deleteStudent);
			cout<<"Student has been deleted"<<endl;
		}
		
		else
		{
		
		cout<<"Student is not present"<<endl;
		}
		
	}
	
	if (userChoice != '9')
	{
		system("pause");
		system("cls");
	}
}
	return 0;
}






void InsertHead(NodeType node, NodePtr& head) // Node is a struct
{
	NodePtr newNode = new NodeType;
	newNode -> name = node.name;
	newNode -> grade = node.grade;
	newNode -> link = NULL;
	
	if (head == NULL)						// head->name == (*head.name)
		head = newNode;
	else
	{
		newNode->link = head;
		head = newNode;
	}

}

void Print(NodePtr head)
{
	NodePtr currPtr = head;
	while(currPtr != NULL)
	{
		cout<<currPtr -> name<<" "<<currPtr -> grade<<" "<<endl;
		currPtr = currPtr -> link;
	}
}

void InsertSorted(NodePtr& head, NodeType value)
// Precondition
//  head is a pointer and is either NULL or points
//        to a structure on the freestore
// Postcondition
//  if head was NULL, it now points to at least one record
//  if head was not NULL, the list grows and is kept in\
//  ascending order
{
	NodePtr newNodePtr;
	NodePtr prevPtr;
	NodePtr currPtr;

	newNodePtr = new NodeType;
	newNodePtr->grade = value.grade;
	newNodePtr->name = value.name;
	

	prevPtr = NULL;
	currPtr = head;
	
	while (currPtr != NULL && value.name > currPtr->name)
	{
		prevPtr = currPtr;
		currPtr = currPtr->link;
	}

	newNodePtr->link = currPtr;
	if (prevPtr == NULL)
		head = newNodePtr;
	else
		prevPtr->link = newNodePtr;
}

void DeleteList(NodePtr& head)
// Precondition
//  head is a pointer and points to a linked list
// Postcondition
//  each value in the list is returned to the heap
{
	NodePtr temp;

	while (head != NULL)
	{
		temp = head->link;
		delete head;
		head = temp;
	}
}

bool IsPresent(NodePtr head, NodeType value)
//Precondition
//  head is a pointer to a linked list 
//Postcondition
//  if the value is in the list, true is returned
//  otherwise false is returned
{
	NodePtr currPtr;
	bool found;

	found = false;

	if (head != NULL)
	{
		currPtr = head;
		while (currPtr != NULL && value.name != currPtr->name)
			currPtr = currPtr->link;
		if (currPtr != NULL)
			found = true;
	}
	return found;
}

void DeleteItem(NodePtr& head, NodeType value)
//Precondition
//   head is a pointer to a linked list
//Postcondition
//   value is delete from the list
//   it is assumed to be there
{
	NodePtr tempPtr;    //used to point to the pointer to delete
	NodePtr currPtr;

	if (value.name == head->name)
	{
		tempPtr = head;
		head = head->link;
	}
	else
	{
		currPtr = head;
		while (currPtr->link->name != value.name)
			currPtr =  currPtr->link;

		tempPtr = currPtr->link;
		currPtr->link = currPtr->link->link;
	}

	delete tempPtr;
}

