/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chatroom;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

/**
 *
 * @author Darren Johnston_2
 */
public class MulticastThread extends Thread{
    private MulticastSocket s; //Socket to connect to
    private String message; //message that is received
    private JTextArea area; //area that is appended to
    
    public MulticastThread(MulticastSocket socket, JTextArea a) throws IOException{
        //Gets a jTextArea to append information to and a socket to receive from
        this.s = socket;
        this.message = "";
        this.area = a;
    }
    
    public void run(){
        while (true){
            byte[] buf = new byte[1000];
                    DatagramPacket recv = new DatagramPacket(buf, buf.length);
            try {
                this.s.receive(recv); //blocking operation;
                String string = "";
                    ByteArrayInputStream bin = new ByteArrayInputStream 
                        (recv.getData());

                        // Display only up to the length of the original UDP packet
                        for (int i=0; i < recv.getLength(); i++)  {
                                int data = bin.read();
                                if (data == -1)
                                        break;
                                else
                                         string += ( (char) data) ;
                        }
                this.message = string;
                area.append(message); //Appends message to chatRoom!
                System.out.println(this.message);
            } catch (IOException ex) {
                Logger.getLogger(MulticastThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
