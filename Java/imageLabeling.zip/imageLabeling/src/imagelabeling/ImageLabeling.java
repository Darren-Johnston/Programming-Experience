/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package imagelabeling;
import java.util.Random;
import java.util.ArrayList;
import java.util.LinkedList;
/**
 *
 * @author Darren Johnston
 */
//Purpose of this assignment was to take all of the 1s in an image and label them appropriately based on if they were beside another 1.
//This class make use of the Queue properties of LinkedList to effectively relabel components in a 7x7 matrix
public class ImageLabeling {

    /**
     * @param args the command line arguments
     */
    
    public static void printArray(int[][] array){
        for (int i = 0; i < array.length; i++){
            for (int k = 0; k < array.length; k++){
                System.out.print(array[i][k]);
            }
            System.out.println();
        }
    }
    
    public static boolean greaterThanOne(int number){
        if (number > 1) return true;
        
        else return false;
        
    }
    
    public static void label (int[][] array, int amount){
        //ArrayList<String> list = new ArrayList<String>();
        LinkedList<String> queue = new LinkedList<String>();
        int count = 2;
        String[] splitter;
        int[] coordinates = new int[2];
        boolean up;
        boolean down;
        boolean right;
        boolean left;
        boolean change = false;
        String temp = "";
        for (int i = 0; i < array.length; i++){ //Go through each row
            for (int k = 0; k < array.length; k++){ //Go through each element in row
                if (array[i][k] == 1){
                    temp = Integer.toString(i) + " " + Integer.toString(k);
                    queue.add(temp); //Holds coordinates of a 1
                    
                    while(queue.size() > 0){
                        up = false;
                        down = false;
                        left = false;
                        right = false;
                        splitter = queue.element().split(" "); //Get first element of queue and it's coordinates in the 7 by 7 matrix
                        //System.out.println(splitter[0]);
                        //System.out.println(splitter[1]);
                        coordinates[0] = Integer.parseInt(splitter[0]);
                        coordinates[1] = Integer.parseInt(splitter[1]);
                        if (coordinates[0] > 0)
                            up = array[coordinates[0] - 1][coordinates[1]] == 1; //does the above element have a 1?
                        if (coordinates[0] < amount)
                            down = array[coordinates[0] + 1][coordinates[1]] == 1; //does the below element have a 1?
                        if (coordinates[1] > 0)
                            left = array[coordinates[0]][coordinates[1] - 1] == 1; //does the left element have a 1?
                        if (coordinates[1] < amount)
                            right = array[coordinates[0]][coordinates[1] + 1] == 1; //does the right element have a 1?
                        
                        if (left){
                            queue.add(Integer.toString(coordinates[0]) + " " + Integer.toString(coordinates[1] - 1));
                            array[coordinates[0]][coordinates[1]-1] = count;
                        }
                        if (right){
                            queue.add(Integer.toString(coordinates[0]) + " " + Integer.toString(coordinates[1] + 1));
                            array[coordinates[0]][coordinates[1]+1] = count;
                        }
                        if (up){
                            queue.add(Integer.toString(coordinates[0]-1) + " " +  Integer.toString(coordinates[1]));
                            array[coordinates[0] - 1][coordinates[1]] = count;
                        }
                        if (down){
                            queue.add(Integer.toString(coordinates[0] + 1) + " " + Integer.toString(coordinates[1]));
                            array[coordinates[0] + 1][coordinates[1]] = count;
                        }
                        
                        if (left || right || up || down){
                            change = true; //if there is a neighbor we want to increment the count to signify a new component
                            array[coordinates[0]][coordinates[1]] = count;
                        }
                        
                        queue.remove();
                    }
                    if (change){
                        count += 1;
                    }
                    change = false;
                }
            }
        }
        
    }
   
    public static void main(String[] args) {
        int count = 2;
        Random r = new Random();
        final int ARRAY_SIZE = 7;
        int[][] array = new int[ARRAY_SIZE][ARRAY_SIZE];
        for (int i = 0; i < array.length; i++){
            for (int k = 0; k < array.length; k++){
                array[i][k] = Math.abs(r.nextInt() % 2);
            }
        }
        System.out.println("Old Array");
        printArray(array);
        label(array, ARRAY_SIZE - 1);
        System.out.println();
        System.out.println("Revised Array");
        printArray(array);
    }
}
