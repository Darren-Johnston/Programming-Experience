//Purpose: This class implements the Hypothetical Operating System
//Note: I accidently got the terms "job queue" and "ready queue" mixed up
//      So when reviewing my code, switch the two definitions.
package hos;
import java.util.Random;
import java.util.ArrayList;
/**
 *
 * @author Darren Johnston
 */
public class HOS {
    private int numProcessors; //Number of processors available
    private int physicalMem; //Total size of the physical memory
    private Memory[] memBlocks; //An array of 7 memBlocks
    private Job[] jobs; //An array of 20 jobs
    private Random r; //Random number generator to fill blocks
    private int timeUnits; //number of units the simulation will run
    private int timeCount; //Keeps up with time
    private ArrayList<Job> readyQueue = new ArrayList<Job>(); //Case1 array
    private ArrayList<Job> readyCopy = new ArrayList<Job>(); //Case2 array
    private ArrayList<Job> readyCopy2 = new ArrayList<Job>(); //Case 3 array
    private ArrayList<Job> jobQueue = new ArrayList<Job>(); //Holds currently running items
    private boolean decisionV = false; //used to input new jobs into job queue
    private boolean flag = false; //used to determine which jobs to process
    private int numWaitings = 0;
    private int completedJobs = 20; //Total jobs to be finished
    
    //Used for debugging and testing
    private void fillJobArray(Job[] jobArray){
        int memRequest;
        int timeRequest;
        for (int i = 0; i < jobs.length; i++){
            memRequest = Math.abs(r.nextInt() % 38) + 12;
            timeRequest = Math.abs(r.nextInt() % 8) + 2;
            
            jobs[i] = new Job(i+1, memRequest, timeRequest);
        }
    }
    
    //Fills the 3 arrays for each case with the same random values
    private void fillJobArray(ArrayList<Job> jobArray, ArrayList<Job> temp1, ArrayList<Job> temp2){
        int memRequest;
        int timeRequest;
        for (int i = 0; i < 20; i++){
            memRequest = Math.abs(r.nextInt() % 38) + 12;
            timeRequest = Math.abs(r.nextInt() % 8) + 2;
            jobArray.add(new Job(i+1, memRequest, timeRequest));
            temp1.add(new Job(i+1, memRequest, timeRequest));
            temp2.add(new Job(i+1, memRequest, timeRequest));
        }
    }
    
    //Sets the memory blocks to their particular sizes and IDs.
    private void fillMemBlocks(){
        memBlocks[0] = new Memory(0, 32);
        memBlocks[1] = new Memory(1, 48);
        memBlocks[2] = new Memory(2, 24);
        memBlocks[3] = new Memory(3, 16);
        memBlocks[4] = new Memory(4, 64);
        memBlocks[5] = new Memory(5, 40);
        memBlocks[6] = new Memory(6, 32);
        //Note total memory = 256
    }
    
    //Performs calculations to gather the total memory wasted
    private int calculateMemoryWasted(){
        int memoryWasted = 0;
        for (Job j: jobQueue){
            memoryWasted += memBlocks[j.getSegNumber()].getSize()
                    - j.getMemAmount();
        }
        
        return memoryWasted;
    }
    
    //Exceptionally important sort for case 3
    private void bubbleSort(ArrayList<Job> array){
        Job temp = new Job(0,0,0);
        
        for (int i = 0; i < array.size()-1; i++){
            temp = new Job(0,0,0);
            for (int k = 0; k < array.size()-1; k++){
                if (array.get(k).getExecutionNumber() > 
                        array.get(k+1).getExecutionNumber()){
                    temp = array.get(k);
                    array.set(k, array.get(k+1));
                    array.set(k+1, temp);
                }
            }
        }
    }
    
    //Used for visuals
    private void createFormat(){
        System.out.println("Time  ID   SEGMENT   MEM REQUEST   TIME REMAIN   MESSAGES");
    }
    
    
    //Initializes a large amount of important variables
    public HOS(){
        numProcessors = 4;
        physicalMem = 256;
        memBlocks = new Memory[7];
        jobs = new Job[20];
        r = new Random();
        timeUnits = 30;
        timeCount = 0;
        
        
        
        fillMemBlocks();
        fillJobArray(jobs); //debugging
        
        //Creates identical arrays for each case
        fillJobArray(readyQueue, readyCopy, readyCopy2);
        int count = 0;
    }
    
    public ArrayList<Job> getReadyQueue(){
        return readyQueue;
    }
    
    public Memory[] getMemBlocks(){
        return memBlocks;
    }
    
    public int getCompletedJobs(){
        return completedJobs;
    }
    
    //Sets the precedent for the other cases. Code here is a base for the others
    public void caseOne(){
        timeCount = 0;
        int count = 0; //Need the exact memory block to assign job to
        ArrayList<Job> temp; //Needed if multiple processes finish together
        
        //Note: FIFO strategy with First-Fit
        while (readyQueue.size() > 0 && timeCount <30 || jobQueue.size() > 0 && timeCount <30){
            temp = new ArrayList<Job>();
            
            for (Job j: readyQueue){
                count = 0;
                for (Memory m: memBlocks){
                    if (!m.getInUse()){
                        if(m.getSize() >= j.getMemAmount()){
                            jobQueue.add(j);
                            temp.add(j);
                            j.setSegNumber(count);
                            m.setUse(true);
                            j.setJobState("Ready");
                            break;
                        }
                    }
                    count += 1;
                }
            }
            
            for (int i = 0; i < temp.size(); i++){
                readyQueue.remove(temp.get(i));
            }
            
            System.out.println();

            decisionV = false;
            boolean flag = false;
            while (decisionV == false){ //Get out when a process reaches timeLeft 0
                decisionV = subtractFromQueue(flag);
                flag = !flag;
            }
        }
        
    }
    
    public void caseTwo(){
        timeCount = 0;
        int count = 0;
        ArrayList<Job> temp;
        boolean add = false;
        int memPos = 0;
        Memory smallest = new Memory(0,100000000); //Larger than any normal memory size
        
        //Note: FIFO strategy with Best-Fit
        
        while (readyCopy.size() > 0 && timeCount <30 || jobQueue.size() > 0 && timeCount<30){
            temp = new ArrayList<Job>();
            
            for (Job j: readyCopy){
                count = 0;
                smallest = new Memory(0,100000000);
                add = false;
                //This section ensures best-fit
                for (Memory m: memBlocks){
                    if (!m.getInUse()){
                        if (m.getSize() < smallest.getSize()){
                            if (m.getSize() > j.getMemAmount()){
                                smallest = m;
                                add = true;
                                memPos = count;
                            }
                        }
                    }
                    count += 1;
                }
                if (add == true){
                    jobQueue.add(j);
                    temp.add(j);
                    j.setSegNumber(memPos);
                    memBlocks[memPos].setUse(true);
                    j.setJobState("Ready");
                    
                }
                
            }
            
            for (int i = 0; i < temp.size(); i++){
                readyCopy.remove(temp.get(i));
            }
            
            System.out.println();

            decisionV = false;
            boolean flag = false;
            //Get out when a process reaches timeLeft == 0
            while (decisionV == false){
                decisionV = subtractFromQueue(flag);
                flag = !flag;
            }
        }
        
    }
    
    //Exactly the same as case 2 except for a bubbleSort
    public void caseThree(){
        timeCount = 0;
        int count = 0;
        ArrayList<Job> temp;
        boolean add = false;
        int memPos = 0;
        Memory smallest = new Memory(0,100000000); //Larger than any normal memory size
        
        //Note: S-J First strategy with Best-Fit
        
        while (readyCopy2.size() > 0 && timeCount <30 || jobQueue.size() > 0 && timeCount<30){
            temp = new ArrayList<Job>();
            bubbleSort(readyCopy2); //Only difference from case 2
            
            for (Job j: readyCopy2){
                count = 0;
                smallest = new Memory(0,100000000);
                add = false;
                
                for (Memory m: memBlocks){
                    if (!m.getInUse()){
                        if (m.getSize() < smallest.getSize()){
                            if (m.getSize() > j.getMemAmount()){
                                smallest = m;
                                add = true;
                                memPos = count;
                            }
                        }
                    }
                    count += 1;
                }
                if (add == true){
                    jobQueue.add(j);
                    temp.add(j);
                    j.setSegNumber(memPos);
                    memBlocks[memPos].setUse(true);
                    j.setJobState("Ready");
                    
                }
                
            }
            
            for (int i = 0; i < temp.size(); i++){
                readyCopy2.remove(temp.get(i));
            }
            
            System.out.println();

            decisionV = false;
            boolean flag = false;
            while (decisionV == false){ //Get out when a process reaches timeLeft 0
                decisionV = subtractFromQueue(flag);
                flag = !flag;
            }
        }
    }
    
    //Major method that provides the time reductions for all three cases
    //This method returns a boolean value that tells the program when a memory 
    //  location is open
    public boolean subtractFromQueue(boolean flag){
            
            //Ensure that the simulation does not exceed 30 time units
            if (timeCount == 30){
                return (true);
            }
            Job value = new Job(0, 0, 0);
            //Tells the method when to back out to get another process into mem.
            boolean returnV = false;
            
            //This temp is needed in case multiple jobs finish simultaneously
            ArrayList<Job> temp = new ArrayList<Job>();
            int hold = 0; //Keeps track of position
            numWaitings = 0; 
            
            if (jobQueue.size() <= numProcessors){
                flag = false; //Allow all jobs to continuously run
            }
            
            for (Job j: jobQueue){
                //Need to differentiate between ready and waiting
                if (j.getJobState() != "Ready"){
                    j.setJobState("Waiting");
                }
                
                //Run first 4 processes
                if (!flag){
                    for (int i = 0; i < numProcessors; i++){
                        if (jobQueue.indexOf(j) == i){
                            j.setJobState("Running");
                            j.decTimeRemain();
                        }
                    }
                }
                
                //Run next 4 processes
                else if (flag){
                    for (int i = 0; i < numProcessors; i++){
                        hold = i + numProcessors;
                        if (hold == jobQueue.size()){
                            hold = 0;
                        }
                        
                        else if (hold > jobQueue.size()){
                            hold = hold - jobQueue.size();
                        }
                        if (jobQueue.indexOf(j) == hold){
                            j.setJobState("Running");
                            j.decTimeRemain();
                        }
                    }
                }
                
                //Free up memory space and get rid of job from queue
                if (j.getTimeRemaining() == 0){
                    memBlocks[j.getSegNumber()].setUse(false);
                    j.setJobState("Finished");
                    value = j;
                    temp.add(value);
                    returnV = true;
                    //break;
                }
            }
            timeCount++; 
            
            //Print all important information to the screen.
            for (Job j: jobQueue){
                System.out.print(timeCount);
                System.out.println(j);
                if (j.getJobState() == "Waiting" || j.getJobState() == "Ready"){
                    numWaitings += 1; 
                }
            }
            System.out.println("Number of waiting processes: " + numWaitings);
            System.out.println("Total amount of memory wasted: " 
                    + calculateMemoryWasted());
            
            for (Job v: temp){
                jobQueue.remove(v);
            }
            System.out.println();
            
            return returnV;
    }
    
    
    public int getTime(){
        return timeCount;
    }
    
    
    //Used for debugging purposes
    public String toString(){
        String totalString = "";
        
        for (Job i: readyQueue){
           totalString += Integer.toString(timeCount) + i + "\n";
        }
        for (Memory m: memBlocks){
            totalString += m;
        }
        return totalString;
    }
    
    //Creates the visuals and runs all three cases
    public static void main(String[] args) {
        HOS op = new HOS();
        System.out.println("Case 1");
        op.createFormat();
        op.caseOne();
        System.out.println("Total jobs completed: " + op.getCompletedJobs());
        
        System.out.println();
        System.out.println("Case 2");
        op.createFormat();
        op.caseTwo();
        System.out.println("Total jobs completed: " + op.getCompletedJobs());
        
        System.out.println();
        System.out.println("Case 3");
        op.createFormat();
        op.caseThree();
        System.out.println("Total jobs completed: " + op.getCompletedJobs());
    }
}