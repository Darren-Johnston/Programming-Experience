//Purpose: To implement the logic and variables for each Job
package hos;

/**
 *
 * @author Darren Johnston
 */
public class Job {
    public int jobNumber; //Unique identification number
    public int memAmount; //in MegaBytes
    public int executionNumber; //Amount of time to finish
    public int segNumber; //Which segment of mem the job is put in
    public int timeRemain; //How much time is left to finish executing
    public String jobState; //The current state of the job
    
    //Initialization
    public Job(int jobNum, int memN, int executeN){
        jobNumber = jobNum;
        memAmount = memN;
        executionNumber = executeN;
        segNumber = 0;
        timeRemain = executeN;
        jobState = "Waiting";
    }
    
    //Getters & Setters
    public int getID(){
        return jobNumber;
    }
    
    public int getMemAmount(){
        return memAmount;
    }
    
    public int getExecutionNumber(){
        return executionNumber;
    }
    
    public int getSegNumber(){
        return segNumber;
    }
    
    public void setSegNumber(int number){
        segNumber = number;
    }
    
    public int getTimeRemaining(){
        return timeRemain;
    }
    
    public void decTimeRemain(){
        timeRemain -= 1;
    }
    
    public String getJobState(){
        return jobState;
    }
    
    public void setJobState(String state){
        jobState = state;
    }
    
    
    
    public String toString(){
        //return ("ID:" + jobNumber + ": Memory Amount: " + memAmount
               // + ": Execution Number: " + executionNumber);
        if (jobNumber < 10){
            return ("     " + jobNumber + "      " 
                    + segNumber + "         " + memAmount + "            " 
                    + "  " + timeRemain + "         " + jobState);
        }
        else{
            return ("     " + jobNumber + "     " 
                    + segNumber + "         " + memAmount + "            " 
                    + "  " + timeRemain + "         " + jobState);
        }
    }
}
