//Purpose: To implement the logic and attributes for Memory

package hos;

/**
 *
 * @author Darren Johnston
 */
public class Memory {
    private int segNumber; //identification number for each memory block
    private int size; //in Megabytes
    private boolean inUse; //whether segment is in use
    private int spaceWasted; //in Megabytes. Total space wasted.
    
    public Memory(int segNum, int s){
        segNumber = segNum;
        size = s;
    }
    
    //Getters and Setters
    public int getSegNumber(){
        return segNumber;
    }
    
    public int getSize(){
        return size;
    }
    
    public boolean getInUse(){
        return inUse;
    }
    
    public int getSpaceWasted(){
        return spaceWasted;
    }
    
    public void setUse(boolean value){
        inUse = value;
    }
    
    //For testing
    public void calcSpaceWasted(int spaceReq, int memSpace){
        spaceWasted = (memSpace - spaceReq);
    }
    
    public String toString(){
        return ("SegNumber: " + segNumber + " Size: " + size + " InUse: "
                + inUse + "\n");
    }
        
}
